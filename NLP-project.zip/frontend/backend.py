# app.py

from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle

app = Flask(__name__)
CORS(app)   # IMPORTANT for frontend connection

# Load trained model
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

@app.route('/')
def home():
    return "Fake News Analyzer Backend Running"

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        text = data['text']

        # Convert text
        vector = vectorizer.transform([text])

        # Predict
        prediction = model.predict(vector)[0]

        # Convert result
        result = "REAL NEWS" if prediction == 1 else "FAKE NEWS"

        return jsonify({
            "prediction": result
        })

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)